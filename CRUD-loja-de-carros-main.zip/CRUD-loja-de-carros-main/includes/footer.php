<footer class="page-footer azul-escuro">
    <div class="container">
      <div class="row center valign-wrapper">
        <div class="col l6 pull-l1 s12">
          <a href="index.php"><img  width="299.19px" src="assets/imagens/monocromatica_branca.svg" alt="Logo de Car Today na cor branca"></a>
          <p class="grey-text text-lighten-4">
            Copyright 2021 - Todos os direitos reservados.
          </p>
        </div>
        <div class="col l6 push-l2 s12">
          <h5 class="white-text">Menu</h5>
          <ul>
            <li><a class="white-text" href="index.php">Home</a></li>
            <li><a class="white-text" href="consultar.php">Consulta</a></li>
            <li><a class="white-text" href="adicionar.php">Adicionar</a></li>
            <li><a class="white-text" href="#relatorios">Relatórios</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <script>
    M.AutoInit();
  </script>
  </body>
</html>